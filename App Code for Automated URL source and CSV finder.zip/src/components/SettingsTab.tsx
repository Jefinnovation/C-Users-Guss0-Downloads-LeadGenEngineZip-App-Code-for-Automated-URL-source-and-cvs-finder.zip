import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Save, Loader2, Eye, EyeOff, RefreshCw, Copy, Check } from 'lucide-react';
import type { Settings } from '@/types';

interface SettingsTabProps {
  onToast: (message: string, type: 'success' | 'error' | 'warning') => void;
}

export function SettingsTab({ onToast }: SettingsTabProps) {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);
  const [copied, setCopied] = useState(false);

  const fetchSettings = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('settings')
      .select('*')
      .eq('id', 1)
      .single();

    if (error) {
      onToast(`Failed to load settings: ${error.message}`, 'error');
    } else {
      setSettings(data);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleSave = async () => {
    if (!settings) return;
    
    setSaving(true);
    const { error } = await supabase
      .from('settings')
      .update({
        max_sources_per_run: settings.max_sources_per_run,
        timeout_per_source: settings.timeout_per_source,
        retry_count: settings.retry_count,
        user_agent: settings.user_agent,
        deduplication_enabled: settings.deduplication_enabled,
        api_key: settings.api_key || null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', 1);

    if (error) {
      onToast(`Failed to save settings: ${error.message}`, 'error');
    } else {
      onToast('Settings saved successfully', 'success');
    }
    setSaving(false);
  };

  const generateApiKey = () => {
    const key = `usf_${crypto.randomUUID().replace(/-/g, '')}`;
    setSettings(prev => prev ? { ...prev, api_key: key } : null);
  };

  const copyApiKey = async () => {
    if (settings?.api_key) {
      await navigator.clipboard.writeText(settings.api_key);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 text-gray-400 animate-spin" />
      </div>
    );
  }

  if (!settings) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Failed to load settings</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl space-y-6">
      {/* Processing Settings */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-200 mb-4">Processing Settings</h3>
        
        <div className="space-y-4">
          {/* Max Sources */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1.5">
              Max Sources Per Run
            </label>
            <input
              type="number"
              value={settings.max_sources_per_run}
              onChange={(e) => setSettings(prev => prev ? { ...prev, max_sources_per_run: parseInt(e.target.value) || 200 } : null)}
              min={1}
              max={1000}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-500">Maximum number of sources to process in a single run (default: 200)</p>
          </div>

          {/* Timeout */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1.5">
              Timeout Per Source (seconds)
            </label>
            <input
              type="number"
              value={settings.timeout_per_source}
              onChange={(e) => setSettings(prev => prev ? { ...prev, timeout_per_source: parseInt(e.target.value) || 20 } : null)}
              min={5}
              max={120}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-500">Request timeout for each URL (default: 20s)</p>
          </div>

          {/* Retry Count */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1.5">
              Retry Count
            </label>
            <input
              type="number"
              value={settings.retry_count}
              onChange={(e) => setSettings(prev => prev ? { ...prev, retry_count: parseInt(e.target.value) || 1 } : null)}
              min={0}
              max={5}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-500">Number of retry attempts for failed requests (default: 1)</p>
          </div>

          {/* User Agent */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1.5">
              User-Agent String
            </label>
            <input
              type="text"
              value={settings.user_agent}
              onChange={(e) => setSettings(prev => prev ? { ...prev, user_agent: e.target.value } : null)}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-500">HTTP User-Agent header sent with requests</p>
          </div>

          {/* Deduplication */}
          <div className="flex items-center justify-between py-2">
            <div>
              <label className="text-sm font-medium text-gray-300">Deduplication</label>
              <p className="text-xs text-gray-500">Prevent duplicate URLs from being processed in the same run</p>
            </div>
            <button
              onClick={() => setSettings(prev => prev ? { ...prev, deduplication_enabled: !prev.deduplication_enabled } : null)}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                settings.deduplication_enabled ? 'bg-emerald-600' : 'bg-gray-700'
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings.deduplication_enabled ? 'left-7' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* API Settings */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-200 mb-4">API Authentication</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1.5">
            API Key
          </label>
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <input
                type={showApiKey ? 'text' : 'password'}
                value={settings.api_key || ''}
                onChange={(e) => setSettings(prev => prev ? { ...prev, api_key: e.target.value } : null)}
                placeholder="No API key set (authentication disabled)"
                className="w-full px-3 py-2 pr-20 bg-gray-800 border border-gray-700 rounded-lg text-gray-100 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {settings.api_key && (
                  <button
                    onClick={copyApiKey}
                    className="p-1 text-gray-400 hover:text-gray-200 transition-colors"
                    title="Copy"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                )}
                <button
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="p-1 text-gray-400 hover:text-gray-200 transition-colors"
                >
                  {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <button
              onClick={generateApiKey}
              className="px-3 py-2 bg-gray-700 hover:bg-gray-600 text-gray-200 rounded-lg transition-colors flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Generate
            </button>
          </div>
          <p className="mt-1 text-xs text-gray-500">
            Required for automation API calls. Send via <code className="text-gray-400">X-API-Key</code> header.
            Leave empty to disable authentication (not recommended).
          </p>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center gap-2 px-6 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-700 text-white rounded-lg transition-colors"
        >
          {saving ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              Save Settings
            </>
          )}
        </button>
      </div>
    </div>
  );
}
