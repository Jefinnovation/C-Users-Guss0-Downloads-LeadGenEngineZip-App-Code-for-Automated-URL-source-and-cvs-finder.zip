import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { JsonViewer } from '@/components/ui/JsonViewer';
import { 
  RefreshCw, 
  Loader2, 
  CheckCircle, 
  XCircle, 
  Clock,
  ChevronDown,
  ChevronRight,
  User,
  Bot
} from 'lucide-react';
import type { Run } from '@/types';

interface RunsTabProps {
  onToast: (message: string, type: 'success' | 'error' | 'warning') => void;
}

export function RunsTab({ onToast }: RunsTabProps) {
  const [runs, setRuns] = useState<Run[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedRuns, setExpandedRuns] = useState<Set<string>>(new Set());

  const fetchRuns = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('runs')
      .select('*')
      .order('started_at', { ascending: false })
      .limit(100);

    if (error) {
      onToast(`Failed to load runs: ${error.message}`, 'error');
    } else {
      setRuns(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchRuns();
  }, []);

  const toggleExpand = (runId: string) => {
    setExpandedRuns(prev => {
      const next = new Set(prev);
      if (next.has(runId)) {
        next.delete(runId);
      } else {
        next.add(runId);
      }
      return next;
    });
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleString();
  };

  const formatDuration = (start: string, end?: string) => {
    if (!end) return 'Running...';
    const startTime = new Date(start).getTime();
    const endTime = new Date(end).getTime();
    const duration = (endTime - startTime) / 1000;
    if (duration < 60) return `${duration.toFixed(1)}s`;
    return `${Math.floor(duration / 60)}m ${Math.floor(duration % 60)}s`;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-emerald-400" />;
      case 'fail':
        return <XCircle className="w-4 h-4 text-red-400" />;
      case 'running':
        return <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      success: 'bg-emerald-900/50 text-emerald-400',
      fail: 'bg-red-900/50 text-red-400',
      running: 'bg-blue-900/50 text-blue-400',
    };
    return (
      <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 text-xs rounded-full ${styles[status] || 'bg-gray-700 text-gray-400'}`}>
        {getStatusIcon(status)}
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  const getModeBadge = (mode: string) => {
    if (mode === 'manual') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-purple-900/50 text-purple-400 text-xs rounded-full">
          <User className="w-3 h-3" />
          Manual
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-cyan-900/50 text-cyan-400 text-xs rounded-full">
        <Bot className="w-3 h-3" />
        Automation
      </span>
    );
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-200">Run History</h2>
        <button
          onClick={fetchRuns}
          className="p-2 text-gray-400 hover:text-gray-200 hover:bg-gray-800 rounded-lg transition-colors"
          title="Refresh"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Runs List */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 text-gray-400 animate-spin" />
          </div>
        ) : runs.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">No runs recorded yet</p>
            <p className="text-gray-600 text-sm mt-1">Runs will appear here after execution</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-800">
            {runs.map((run) => (
              <div key={run.run_id} className="hover:bg-gray-800/30 transition-colors">
                {/* Run Header */}
                <button
                  onClick={() => toggleExpand(run.run_id)}
                  className="w-full px-4 py-3 flex items-center gap-4 text-left"
                >
                  <div className="text-gray-400">
                    {expandedRuns.has(run.run_id) ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </div>
                  
                  <div className="flex-1 grid grid-cols-7 gap-4 items-center">
                    <div className="col-span-2">
                      <span className="text-gray-300 font-mono text-xs">{run.run_id.slice(0, 8)}...</span>
                    </div>
                    <div>
                      {getModeBadge(run.mode)}
                    </div>
                    <div className="text-gray-400 text-sm">
                      {formatDate(run.started_at)}
                    </div>
                    <div className="text-gray-500 text-sm">
                      {formatDuration(run.started_at, run.finished_at)}
                    </div>
                    <div>
                      {getStatusBadge(run.status)}
                    </div>
                    <div className="text-right">
                      <span className="text-gray-400 text-sm">
                        {run.processed_count} processed
                        {run.error_count > 0 && (
                          <span className="text-red-400 ml-2">({run.error_count} errors)</span>
                        )}
                      </span>
                    </div>
                  </div>
                </button>

                {/* Expanded Content */}
                {expandedRuns.has(run.run_id) && run.response_json && (
                  <div className="px-4 pb-4 pl-12">
                    <JsonViewer data={run.response_json} collapsed={false} />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
