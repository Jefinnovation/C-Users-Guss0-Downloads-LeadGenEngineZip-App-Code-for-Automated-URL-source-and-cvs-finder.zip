import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { normalizeUrl } from '@/lib/coreEngine';
import { SourceModal } from '@/components/SourceModal';
import { 
  Plus, 
  Play, 
  Pencil, 
  Trash2, 
  ToggleLeft, 
  ToggleRight,
  RefreshCw,
  CheckCircle,
  XCircle,
  Clock,
  Loader2
} from 'lucide-react';
import type { Source, SourceInput, RunResponse } from '@/types';

interface SourcesTabProps {
  onToast: (message: string, type: 'success' | 'error' | 'warning') => void;
}

export function SourcesTab({ onToast }: SourcesTabProps) {
  const [sources, setSources] = useState<Source[]>([]);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingSource, setEditingSource] = useState<Source | null>(null);

  const fetchSources = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('sources')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      onToast(`Failed to load sources: ${error.message}`, 'error');
    } else {
      setSources(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchSources();
  }, []);

  const handleAddSource = () => {
    setEditingSource(null);
    setModalOpen(true);
  };

  const handleEditSource = (source: Source) => {
    setEditingSource(source);
    setModalOpen(true);
  };

  const handleSaveSource = async (input: SourceInput) => {
    const normalized = normalizeUrl(input.url);
    
    if (editingSource) {
      const { error } = await supabase
        .from('sources')
        .update({
          name: input.name,
          url: input.url,
          normalized_url: normalized,
          type: input.type,
          tags: input.tags,
          active: input.active,
          notes: input.notes,
          updated_at: new Date().toISOString(),
        })
        .eq('id', editingSource.id);

      if (error) {
        onToast(`Failed to update source: ${error.message}`, 'error');
      } else {
        onToast('Source updated successfully', 'success');
        setModalOpen(false);
        fetchSources();
      }
    } else {
      const { error } = await supabase
        .from('sources')
        .insert({
          name: input.name,
          url: input.url,
          normalized_url: normalized,
          type: input.type,
          tags: input.tags,
          active: input.active,
          notes: input.notes,
        });

      if (error) {
        onToast(`Failed to add source: ${error.message}`, 'error');
      } else {
        onToast('Source added successfully', 'success');
        setModalOpen(false);
        fetchSources();
      }
    }
  };

  const handleToggleActive = async (source: Source) => {
    const { error } = await supabase
      .from('sources')
      .update({ 
        active: !source.active,
        updated_at: new Date().toISOString(),
      })
      .eq('id', source.id);

    if (error) {
      onToast(`Failed to toggle source: ${error.message}`, 'error');
    } else {
      onToast(`Source ${source.active ? 'disabled' : 'enabled'}`, 'success');
      fetchSources();
    }
  };

  const handleDeleteSource = async (source: Source) => {
    const { error } = await supabase
      .from('sources')
      .delete()
      .eq('id', source.id);

    if (error) {
      onToast(`Failed to delete source: ${error.message}`, 'error');
    } else {
      onToast('Source deleted', 'success');
      fetchSources();
    }
  };

  const handleRunNow = async () => {
    setRunning(true);
    try {
      // Call the edge function - uses the SAME core engine as automation
      const { data, error } = await supabase.functions.invoke('url-source-run', {
        body: { run_mode: 'manual' },
      });

      if (error) {
        throw new Error(error.message);
      }

      const result = data as RunResponse;
      if (result.status === 'success') {
        onToast(`Run complete: ${result.processed_sources.length} sources processed`, 'success');
      } else {
        onToast(`Run completed with errors: ${result.errors.length} errors`, 'warning');
      }
      fetchSources();
    } catch (err) {
      onToast(`Run failed: ${err instanceof Error ? err.message : 'Unknown error'}`, 'error');
    }
    setRunning(false);
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleString();
  };

  const getStatusBadge = (source: Source) => {
    if (!source.last_result_status) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-700 text-gray-400 text-xs rounded-full">
          <Clock className="w-3 h-3" />
          Never checked
        </span>
      );
    }
    if (source.last_result_status === 'success') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-900/50 text-emerald-400 text-xs rounded-full">
          <CheckCircle className="w-3 h-3" />
          Success
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-900/50 text-red-400 text-xs rounded-full">
        <XCircle className="w-3 h-3" />
        Error
      </span>
    );
  };

  const getTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      CSV: 'bg-blue-900/50 text-blue-400',
      HTML: 'bg-purple-900/50 text-purple-400',
      JSON: 'bg-amber-900/50 text-amber-400',
      Unknown: 'bg-gray-700 text-gray-400',
    };
    return (
      <span className={`px-2 py-0.5 text-xs rounded-full ${colors[type] || colors.Unknown}`}>
        {type}
      </span>
    );
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={handleAddSource}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Source
          </button>
          <button
            onClick={handleRunNow}
            disabled={running || sources.filter(s => s.active).length === 0}
            className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-700 disabled:text-gray-500 text-white rounded-lg transition-colors"
          >
            {running ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Running...
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Run Now
              </>
            )}
          </button>
        </div>
        <button
          onClick={fetchSources}
          className="p-2 text-gray-400 hover:text-gray-200 hover:bg-gray-800 rounded-lg transition-colors"
          title="Refresh"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Table */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 text-gray-400 animate-spin" />
          </div>
        ) : sources.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">No sources configured</p>
            <p className="text-gray-600 text-sm mt-1">Click "Add Source" to get started</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-800/50 text-left">
                  <th className="px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Name</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">URL</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Type</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Tags</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Last Checked</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Last Result</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {sources.map((source) => (
                  <tr key={source.id} className="hover:bg-gray-800/30 transition-colors">
                    <td className="px-4 py-3">
                      <button
                        onClick={() => handleToggleActive(source)}
                        className="flex items-center gap-2"
                        title={source.active ? 'Click to disable' : 'Click to enable'}
                      >
                        {source.active ? (
                          <>
                            <ToggleRight className="w-6 h-6 text-emerald-400" />
                            <span className="text-xs text-emerald-400">Active</span>
                          </>
                        ) : (
                          <>
                            <ToggleLeft className="w-6 h-6 text-gray-500" />
                            <span className="text-xs text-gray-500">Disabled</span>
                          </>
                        )}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-gray-200 font-medium">{source.name}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-gray-400 font-mono text-sm truncate block max-w-xs" title={source.url}>
                        {source.url}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {getTypeBadge(source.type)}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        {source.tags && source.tags.length > 0 ? (
                          source.tags.slice(0, 3).map((tag) => (
                            <span key={tag} className="px-1.5 py-0.5 bg-gray-700 text-gray-400 text-xs rounded">
                              {tag}
                            </span>
                          ))
                        ) : (
                          <span className="text-gray-600 text-xs">—</span>
                        )}
                        {source.tags && source.tags.length > 3 && (
                          <span className="text-gray-500 text-xs">+{source.tags.length - 3}</span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-gray-400 text-sm">{formatDate(source.last_checked_at)}</span>
                    </td>
                    <td className="px-4 py-3">
                      {getStatusBadge(source)}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleEditSource(source)}
                          className="p-1.5 text-gray-400 hover:text-blue-400 hover:bg-gray-800 rounded transition-colors"
                          title="Edit"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteSource(source)}
                          className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-gray-800 rounded transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Source Modal */}
      <SourceModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onSave={handleSaveSource}
        source={editingSource}
      />
    </div>
  );
}
