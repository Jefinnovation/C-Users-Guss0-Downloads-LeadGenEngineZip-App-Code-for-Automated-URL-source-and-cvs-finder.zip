import { useState, useCallback } from 'react';
import { SourcesTab } from '@/components/SourcesTab';
import { RunsTab } from '@/components/RunsTab';
import { SettingsTab } from '@/components/SettingsTab';
import { ReadmeTab } from '@/components/ReadmeTab';
import { Toast, ToastType } from '@/components/ui/Toast';
import { 
  Database, 
  History, 
  Settings, 
  BookOpen,
  Zap
} from 'lucide-react';

type Tab = 'sources' | 'runs' | 'settings' | 'readme';

interface ToastItem {
  id: string;
  message: string;
  type: ToastType;
}

export default function AppLayout() {
  const [activeTab, setActiveTab] = useState<Tab>('sources');
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const addToast = useCallback((message: string, type: ToastType) => {
    const id = crypto.randomUUID();
    setToasts(prev => [...prev, { id, message, type }]);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'sources', label: 'Sources', icon: <Database className="w-4 h-4" /> },
    { id: 'runs', label: 'Runs / Logs', icon: <History className="w-4 h-4" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
    { id: 'readme', label: 'README', icon: <BookOpen className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      {/* Header */}
      <header className="bg-gray-900 border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-lg">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-100">URL Source Finder</h1>
                <p className="text-xs text-gray-500">Automation Service</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-1 bg-emerald-900/30 text-emerald-400 text-xs font-medium rounded-full">
                Production Ready
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Tab Navigation */}
      <nav className="bg-gray-900/50 border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-700'
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'sources' && <SourcesTab onToast={addToast} />}
        {activeTab === 'runs' && <RunsTab onToast={addToast} />}
        {activeTab === 'settings' && <SettingsTab onToast={addToast} />}
        {activeTab === 'readme' && <ReadmeTab />}
      </main>

      {/* Toast Notifications */}
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          message={toast.message}
          type={toast.type}
          onClose={() => removeToast(toast.id)}
        />
      ))}
    </div>
  );
}
