import { useState } from 'react';
import { Copy, Check } from 'lucide-react';

export function ReadmeTab() {
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = async (text: string, section: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(section);
    setTimeout(() => setCopied(null), 2000);
  };

  const curlExample = `curl -X POST \\
  https://hojegkvlqgybjeubhhiw.supabase.co/functions/v1/url-source-run \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: YOUR_API_KEY" \\
  -d '{"run_mode": "automation"}'`;

  return (
    <div className="max-w-4xl space-y-8">
      <section>
        <h2 className="text-xl font-bold text-gray-100 mb-3">URL Source Finder</h2>
        <p className="text-gray-400 leading-relaxed">
          A production-grade automation service for checking and monitoring URL sources. 
          Designed for integration with n8n workflows and other automation platforms.
        </p>
        <div className="mt-4 p-4 bg-emerald-900/20 border border-emerald-800 rounded-lg">
          <p className="text-emerald-400 text-sm font-medium">
            UI and Automation share the same core execution engine
          </p>
        </div>
      </section>

      <section>
        <h3 className="text-lg font-semibold text-gray-200 mb-3">Automation API</h3>
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2 py-0.5 bg-emerald-900/50 text-emerald-400 text-xs font-mono rounded">POST</span>
            <code className="text-gray-300 text-sm">/functions/v1/url-source-run</code>
          </div>
        </div>
      </section>

      <section>
        <h3 className="text-lg font-semibold text-gray-200 mb-3">curl Example</h3>
        <div className="relative bg-gray-950 border border-gray-800 rounded-lg p-4">
          <button
            onClick={() => copyToClipboard(curlExample, 'curl')}
            className="absolute top-2 right-2 p-1.5 bg-gray-700 hover:bg-gray-600 rounded"
          >
            {copied === 'curl' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-gray-400" />}
          </button>
          <pre className="text-gray-300 text-xs font-mono overflow-x-auto whitespace-pre-wrap">{curlExample}</pre>
        </div>
      </section>

      <section>
        <h3 className="text-lg font-semibold text-gray-200 mb-3">Response Schema</h3>
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-4 text-sm text-gray-400">
          <p>Every response includes: <code className="text-gray-300">run_id</code>, <code className="text-gray-300">status</code>, <code className="text-gray-300">processed_sources[]</code>, <code className="text-gray-300">errors[]</code>, <code className="text-gray-300">timestamp</code></p>
        </div>
      </section>
    </div>
  );
}
