// Source types
export interface Source {
  id: string;
  name: string;
  url: string;
  normalized_url: string;
  type: 'CSV' | 'HTML' | 'JSON' | 'Unknown';
  tags: string[];
  active: boolean;
  notes?: string;
  created_at: string;
  updated_at: string;
  last_checked_at?: string;
  last_http_status?: number;
  last_content_type?: string;
  last_final_url?: string;
  last_result_status?: 'success' | 'error';
  last_error?: string;
}

export interface SourceInput {
  name: string;
  url: string;
  type?: 'CSV' | 'HTML' | 'JSON' | 'Unknown';
  tags?: string[];
  active?: boolean;
  notes?: string;
}

// Run types
export interface Run {
  run_id: string;
  mode: 'manual' | 'automation';
  started_at: string;
  finished_at?: string;
  status: 'running' | 'success' | 'fail';
  processed_count: number;
  error_count: number;
  response_json?: RunResponse;
}

// Settings types
export interface Settings {
  id: number;
  max_sources_per_run: number;
  timeout_per_source: number;
  retry_count: number;
  user_agent: string;
  deduplication_enabled: boolean;
  api_key?: string;
  updated_at: string;
}

// Core engine types
export interface RunSourcesParams {
  run_mode: 'manual' | 'automation';
  sourcesOverride?: string[];
}

export interface ProcessedSource {
  url: string;
  normalized_url: string;
  http_status: number | null;
  content_type: string | null;
  final_url: string | null;
  status: 'success' | 'error';
  data: {
    title?: string;
    content_length?: number;
    is_csv_like: boolean;
  };
  error?: string;
}

export interface RunResponse {
  run_id: string;
  status: 'success' | 'fail';
  processed_sources: ProcessedSource[];
  errors: string[];
  timestamp: string;
}

// API types
export interface AutomationRequest {
  run_mode: 'automation';
  sources?: string[];
}

export interface ApiError {
  error: string;
  code: number;
  timestamp: string;
}
