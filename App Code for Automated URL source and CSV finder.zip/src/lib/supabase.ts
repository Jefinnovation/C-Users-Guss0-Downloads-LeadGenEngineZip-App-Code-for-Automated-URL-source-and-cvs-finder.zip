import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://hojegkvlqgybjeubhhiw.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI1NTFlMTk2LTRhMzctNDU3Ny05ZDNiLWQ2ODgzOTM1MWExOCJ9.eyJwcm9qZWN0SWQiOiJob2plZ2t2bHFneWJqZXViaGhpdyIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzY3MjI3ODQ3LCJleHAiOjIwODI1ODc4NDcsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.-I5ny414kOsXlqoFAdtNrkS8ZFx4eVgFsOJfpy5HJTM';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };