import { supabase } from '@/lib/supabase';
import type { 
  Source, 
  Settings, 
  RunSourcesParams, 
  ProcessedSource, 
  RunResponse 
} from '@/types';

/**
 * Normalize URL for deduplication
 * - trim whitespace
 * - lowercase host
 * - remove trailing slashes
 */
export function normalizeUrl(url: string): string {
  try {
    const trimmed = url.trim();
    const parsed = new URL(trimmed);
    parsed.hostname = parsed.hostname.toLowerCase();
    let normalized = parsed.toString();
    // Remove trailing slash (except for root path)
    if (normalized.endsWith('/') && parsed.pathname !== '/') {
      normalized = normalized.slice(0, -1);
    }
    return normalized;
  } catch {
    return url.trim().toLowerCase();
  }
}

/**
 * Detect source type from URL or content-type
 */
export function detectSourceType(url: string, contentType?: string): 'CSV' | 'HTML' | 'JSON' | 'Unknown' {
  const lowerUrl = url.toLowerCase();
  const lowerContentType = (contentType || '').toLowerCase();
  
  if (lowerUrl.endsWith('.csv') || lowerContentType.includes('text/csv')) {
    return 'CSV';
  }
  if (lowerUrl.endsWith('.json') || lowerContentType.includes('application/json')) {
    return 'JSON';
  }
  if (lowerContentType.includes('text/html')) {
    return 'HTML';
  }
  return 'Unknown';
}

/**
 * Check if content appears to be CSV-like
 */
function isCsvLike(contentType: string | null, url: string): boolean {
  if (!contentType) return false;
  const lower = contentType.toLowerCase();
  return lower.includes('text/csv') || 
         lower.includes('text/plain') && url.toLowerCase().endsWith('.csv');
}

/**
 * Extract title from HTML content (simple regex approach)
 */
function extractTitle(html: string): string | undefined {
  const match = html.match(/<title[^>]*>([^<]+)<\/title>/i);
  return match ? match[1].trim().slice(0, 200) : undefined;
}

/**
 * Fetch settings from database
 */
export async function getSettings(): Promise<Settings> {
  const { data, error } = await supabase
    .from('settings')
    .select('*')
    .eq('id', 1)
    .single();
  
  if (error || !data) {
    // Return defaults if settings not found
    return {
      id: 1,
      max_sources_per_run: 200,
      timeout_per_source: 20,
      retry_count: 1,
      user_agent: 'URLSourceFinder/1.0',
      deduplication_enabled: true,
      updated_at: new Date().toISOString()
    };
  }
  
  return data as Settings;
}

/**
 * Get active sources from database
 */
export async function getActiveSources(): Promise<Source[]> {
  const { data, error } = await supabase
    .from('sources')
    .select('*')
    .eq('active', true)
    .order('created_at', { ascending: false });
  
  if (error) {
    throw new Error(`Failed to fetch sources: ${error.message}`);
  }
  
  return (data || []) as Source[];
}

/**
 * Process a single URL and return metadata
 */
async function processUrl(
  url: string, 
  normalizedUrl: string,
  settings: Settings
): Promise<ProcessedSource> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), settings.timeout_per_source * 1000);
  
  let lastError: string | undefined;
  let attempts = 0;
  
  while (attempts <= settings.retry_count) {
    attempts++;
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'User-Agent': settings.user_agent,
        },
        signal: controller.signal,
        redirect: 'follow',
      });
      
      clearTimeout(timeoutId);
      
      const contentType = response.headers.get('content-type');
      const contentLength = response.headers.get('content-length');
      
      let title: string | undefined;
      if (contentType?.includes('text/html')) {
        try {
          const text = await response.text();
          title = extractTitle(text);
        } catch {
          // Ignore title extraction errors
        }
      }
      
      return {
        url,
        normalized_url: normalizedUrl,
        http_status: response.status,
        content_type: contentType,
        final_url: response.url,
        status: response.ok ? 'success' : 'error',
        data: {
          title,
          content_length: contentLength ? parseInt(contentLength, 10) : undefined,
          is_csv_like: isCsvLike(contentType, url),
        },
        error: response.ok ? undefined : `HTTP ${response.status}`,
      };
    } catch (err) {
      lastError = err instanceof Error ? err.message : 'Unknown error';
      if (attempts > settings.retry_count) {
        break;
      }
    }
  }
  
  clearTimeout(timeoutId);
  
  return {
    url,
    normalized_url: normalizedUrl,
    http_status: null,
    content_type: null,
    final_url: null,
    status: 'error',
    data: {
      is_csv_like: false,
    },
    error: lastError || 'Request failed',
  };
}

/**
 * Update source with last run results
 */
async function updateSourceResult(sourceId: string, result: ProcessedSource): Promise<void> {
  await supabase
    .from('sources')
    .update({
      last_checked_at: new Date().toISOString(),
      last_http_status: result.http_status,
      last_content_type: result.content_type,
      last_final_url: result.final_url,
      last_result_status: result.status,
      last_error: result.error || null,
      type: detectSourceType(result.url, result.content_type || undefined),
      updated_at: new Date().toISOString(),
    })
    .eq('id', sourceId);
}

/**
 * SHARED CORE EXECUTION ENGINE
 * This is the ONE function that handles all URL processing
 * Called by both UI "Run Now" and HTTP API automation endpoint
 */
export async function runSources(params: RunSourcesParams): Promise<RunResponse> {
  const { run_mode, sourcesOverride } = params;
  const runId = crypto.randomUUID();
  const startTime = new Date().toISOString();
  const errors: string[] = [];
  const processedSources: ProcessedSource[] = [];
  
  // Create run record
  await supabase.from('runs').insert({
    run_id: runId,
    mode: run_mode,
    started_at: startTime,
    status: 'running',
  });
  
  try {
    // Get settings
    const settings = await getSettings();
    
    // Determine which URLs to process
    let urlsToProcess: { url: string; normalized: string; sourceId?: string }[] = [];
    
    if (sourcesOverride && sourcesOverride.length > 0) {
      // Use override URLs (no source IDs to update)
      urlsToProcess = sourcesOverride.map(url => ({
        url,
        normalized: normalizeUrl(url),
      }));
    } else {
      // Get active sources from database
      const sources = await getActiveSources();
      urlsToProcess = sources.map(s => ({
        url: s.url,
        normalized: s.normalized_url,
        sourceId: s.id,
      }));
    }
    
    // Apply max sources limit
    if (urlsToProcess.length > settings.max_sources_per_run) {
      urlsToProcess = urlsToProcess.slice(0, settings.max_sources_per_run);
    }
    
    // Deduplicate if enabled
    if (settings.deduplication_enabled) {
      const seen = new Set<string>();
      urlsToProcess = urlsToProcess.filter(item => {
        if (seen.has(item.normalized)) {
          return false;
        }
        seen.add(item.normalized);
        return true;
      });
    }
    
    // Process each URL
    for (const item of urlsToProcess) {
      try {
        const result = await processUrl(item.url, item.normalized, settings);
        processedSources.push(result);
        
        // Update source record if we have a sourceId
        if (item.sourceId) {
          await updateSourceResult(item.sourceId, result);
        }
      } catch (err) {
        const errorMsg = `Failed to process ${item.url}: ${err instanceof Error ? err.message : 'Unknown error'}`;
        errors.push(errorMsg);
        
        processedSources.push({
          url: item.url,
          normalized_url: item.normalized,
          http_status: null,
          content_type: null,
          final_url: null,
          status: 'error',
          data: { is_csv_like: false },
          error: errorMsg,
        });
      }
    }
    
    // Calculate counts
    const errorCount = processedSources.filter(s => s.status === 'error').length;
    const hasErrors = errorCount > 0 || errors.length > 0;
    const allFailed = processedSources.length > 0 && errorCount === processedSources.length;
    
    // Build response
    const response: RunResponse = {
      run_id: runId,
      status: allFailed ? 'fail' : 'success',
      processed_sources: processedSources,
      errors,
      timestamp: new Date().toISOString(),
    };
    
    // Update run record
    await supabase
      .from('runs')
      .update({
        finished_at: new Date().toISOString(),
        status: allFailed ? 'fail' : 'success',
        processed_count: processedSources.length,
        error_count: errorCount,
        response_json: response,
      })
      .eq('run_id', runId);
    
    return response;
    
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : 'Unknown error';
    errors.push(errorMsg);
    
    const response: RunResponse = {
      run_id: runId,
      status: 'fail',
      processed_sources: processedSources,
      errors,
      timestamp: new Date().toISOString(),
    };
    
    // Update run record with failure
    await supabase
      .from('runs')
      .update({
        finished_at: new Date().toISOString(),
        status: 'fail',
        processed_count: processedSources.length,
        error_count: errors.length,
        response_json: response,
      })
      .eq('run_id', runId);
    
    return response;
  }
}
